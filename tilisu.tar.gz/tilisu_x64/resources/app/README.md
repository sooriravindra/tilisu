# Tilisu
A notification server for your PC


Work regularly on remote VMs with long running tasks? tilisu is solution to all your woes.

**Tilisu provides two important functions:**
* Provide your system info so that you can access your PC info such as charging status, battery percentage etc on remote VM. 
(Can be used to display these on tmux status bar for example)
* Provide a notification system on your desktop so that you can send notifications to your PC from your remote VM.

